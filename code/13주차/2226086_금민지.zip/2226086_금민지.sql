-- 2226086 금민지

-- 1. 기본 테이블 생성
CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name   VARCHAR(20) NOT NULL,
    cell   CHAR(13) NOT NULL UNIQUE,
    addr   VARCHAR(100),
    c_code INTEGER DEFAULT 3
);

CREATE TABLE staff (
    staff_id  INTEGER PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  NUMERIC(6) NOT NULL,
    tel       CHAR(12),
    salary    NUMERIC(9),
    t_code    INTEGER NOT NULL,
    hire_date CHAR(8) NOT NULL
);

CREATE TABLE tour (
    tour_num  CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival   VARCHAR(50) NOT NULL,
    program   VARCHAR(100),
    start_dt  DATE NOT NULL,
    end_dt    DATE NOT NULL,
    min_num   INTEGER,
    max_num   INTEGER,
    expense   NUMERIC(7) NOT NULL,
    deposit   NUMERIC(6),
    dept_yn   CHAR(1) DEFAULT 'N',
    staff_id  INTEGER,
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id),
    CONSTRAINT chk_tour_dept_yn CHECK (dept_yn IN ('Y', 'N'))
);

CREATE TABLE tour_bus (
    bus_id   INTEGER PRIMARY KEY,
    seat     INTEGER,
    del_year INTEGER
);

CREATE TABLE driver (
    driver_id INTEGER PRIMARY KEY,
    name      VARCHAR(20) NOT NULL,
    birthday  CHAR(6) NOT NULL,
    cell      CHAR(13) NOT NULL,
    pay       NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

CREATE TABLE reserve (
    cus_id   VARCHAR(15),
    tour_num CHAR(8),
    res_date DATE DEFAULT CURRENT_DATE,
    dep_yn   CHAR(1) DEFAULT 'N',
    exp_yn   CHAR(1) DEFAULT 'N',
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    CONSTRAINT chk_reserve_dep_yn CHECK (dep_yn IN ('Y', 'N')),
    CONSTRAINT chk_reserve_exp_yn CHECK (exp_yn IN ('Y', 'N'))
);

CREATE TABLE assign_driver (
    tour_num  CHAR(8) PRIMARY KEY,
    driver_id INTEGER,
    work_hour INTEGER,
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

CREATE TABLE assign_bus (
    tour_num CHAR(8) PRIMARY KEY,
    bus_id   INTEGER,
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

CREATE TABLE class_code (
    code  INTEGER PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code INTEGER PRIMARY KEY,
    task VARCHAR(30)
);

-- 2. 인덱스 생성
CREATE INDEX tour_arrival_idx
ON tour (arrival ASC);

CREATE INDEX driver_name_idx
ON driver (name ASC);

-- 3. 초기 데이터 삽입
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('C001', '김ㅇㅇ', '010-1111-1111', '서울시 강남구', 1),
('C002', '이ㅇㅇ', '010-2222-2222', '경기도 일산시', 2),
('C003', '박ㅇㅇ', '010-3333-3333', '부산시 해운대구', 3),
('C004', '최ㅇㅇ', '010-4444-4444', '충청북도 충주시', 3),
('C005', '장ㅇㅇ', '010-5555-5555', '충청남도 천안시', 2);

INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
(10001, '강ㅇㅇ', '900101', '02-1111-1111', 3200000, 1, '20210110'),
(10002, '한ㅇㅇ', '920315', '02-2222-2222', 3000000, 2, '20220315'),
(10003, '오ㅇㅇ', '880720', '02-3333-3333', 3500000, 3, '20200720'),
(10004, '윤ㅇㅇ', '950905', '02-4444-4444', 2800000, 4, '20230501'),
(10005, '서ㅇㅇ', '910212', '02-5555-5555', 3100000, 5, '20211111');

INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('T2026001', '서울', '제주', 'https://tour.example.com/jeju', '2026-07-01', '2026-07-03', 10, 30, 450000, 100000, 'N', 10001),
('T2026002', '서울', '부산', 'https://tour.example.com/busan', '2026-07-05', '2026-07-06', 8, 25, 230000, 50000, 'N', 10001),
('T2026003', '서울', '강릉', 'https://tour.example.com/gangneung', '2026-07-10', '2026-07-11', 6, 20, 180000, 40000, 'N', 10001),
('T2026004', '서울', '여수', 'https://tour.example.com/yeosu', '2026-07-15', '2026-07-16', 10, 28, 210000, 50000, 'N', 10001),
('T2026005', '서울', '경주', 'https://tour.example.com/gyeongju', '2026-07-20', '2026-07-22', 12, 35, 360000, 80000, 'N', 10001);

INSERT INTO tour_bus (bus_id, seat, del_year) VALUES
(1, 45, 2020),
(2, 40, 2021),
(3, 35, 2019),
(4, 45, 2022),
(5, 30, 2023);

INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
(20001, '장ㅇㅇ', '850101', '010-0000-1111', 18000, '20240101', '12'),
(20002, '문ㅇㅇ', '870202', '010-0000-2222', 17000, '20240201', '12'),
(20003, '김ㅇㅇ', '900303', '010-0000-3333', 16000, '20240301', '24'),
(20004, '신ㅇㅇ', '880404', '010-0000-4444', 19000, '20240401', '12'),
(20005, '권ㅇㅇ', '860505', '010-0000-5555', 15000, '20240501', '6');

INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('C001', 'T2026001', '2026-06-01', 'Y', 'N'),
('C002', 'T2026001', '2026-06-02', 'Y', 'Y'),
('C003', 'T2026002', '2026-06-03', 'N', 'N'),
('C004', 'T2026003', '2026-06-04', 'Y', 'N'),
('C005', 'T2026004', '2026-06-05', 'N', 'N');

INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('T2026001', 20001, 8),
('T2026002', 20002, 6),
('T2026003', 20003, 5),
('T2026004', 20004, 6),
('T2026005', 20005, 8);

INSERT INTO assign_bus (tour_num, bus_id) VALUES
('T2026001', 1),
('T2026002', 2),
('T2026003', 3),
('T2026004', 4),
('T2026005', 5);

INSERT INTO class_code (code, class, basis) VALUES
(1, '최우수', '누적예약 10회 이상'),
(2, '우수', '누적예약 5회 이상'),
(3, '일반', '신규 및 일반고객');

INSERT INTO task_code (code, task) VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

-- 4. 필수 테스트 SQL
-- 4-1. 고객 등급 검색
SELECT c.name AS 고객명,
       cc.class AS 고객등급
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'C001';

-- 4-2. 직원 담당업무 검색
SELECT s.name AS 직원명,
       tc.task AS 담당업무
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10002;

-- 4-3. 여행상품 예약 고객 검색
SELECT c.name AS 고객명,
       r.res_date AS 예약일자,
       r.dep_yn AS 예약금결제여부
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T2026001';

-- 4-4. 여행상품에 배정된 운전기사 검색
SELECT t.departure AS 출발지,
       d.name AS 운전기사명,
       d.cell AS 휴대폰번호
FROM tour t
JOIN assign_driver ad ON t.tour_num = ad.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'T2026001';

-- 4-5. 신규 고객 등록
SELECT * FROM customer;

INSERT INTO customer (cus_id, name, cell)
VALUES ('C006', '이ㅇㅇ', '010-6666-6666');

-- 4-6. 직원 급여 수정 : 사번이 10002인 직원 급여 200000원 증가
SELECT * FROM staff;

UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10002;

-- 4-7. 예약 정보 삭제
SELECT * FROM reserve;

DELETE FROM reserve
WHERE cus_id = 'C005'
  AND tour_num = 'T2026004';
